package Pessoa;

import java.util.Date;

public class Pessoa {
	
	String nome;
	int cpf;
	String endereco;
	char sexo; //M - masculino, F - Feminino e O - outros e indecisos
	int idade;
	Date dataNasc;
	int telefone;
	String rg;
	double salario;
	
	public Pessoa(){};
	
	/**
	 * Metodo construtor da Classe Pessoa.
	 * @param nome
	 * @param cpf
	 * @param endereco
	 * @param sexo
	 * @param idade
	 * @param dataNasc
	 * @param telefone
	 * @param rg
	 * @param salario
	 */
	
	public Pessoa(String nome, int cpf, String endereco, char sexo, int idade, Date dataNasc, int telefone, String rg, double salario){
		
		this.nome = nome;
		this.cpf = cpf;
		this.endereco = endereco;
		this.sexo = sexo;
		this.idade = idade;
		this.dataNasc = dataNasc;
		this.telefone = telefone;
		this.rg = rg;
		this.salario = salario;
		
		
	}
	
	/**
	 * 
	 * @param salario
	 */
	
	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public int getCpf(){
		return cpf;
	}
	
	public void setCpf(int cpf){
		this.cpf = cpf;
		
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public Date getDataNasc() {
		return dataNasc;
	}

	public void setDataNasc(Date dataNasc) {
		this.dataNasc = dataNasc;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}
	
	

}
