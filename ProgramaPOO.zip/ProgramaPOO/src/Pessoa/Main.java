package Pessoa;

import java.util.Date;

public class Main {
	
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Pessoa p1;
		
		p1 = new Pessoa("Gianescleia Beijamin", 6666666, "Rua 5, 36 numero 0", 'M', 86, new Date("28/02/1929"), 99997070, "MG-11111111", 740.00);
		
		Pessoa p2 = new Pessoa();
		
		p2.setSalario(9000.00);
		p1.setSalario(15000.00);
		
		p2.setNome("Chestter Filha");
		p2.setSexo('F');
		
		System.out.println(p1.getNome());
		System.out.println(p2.getNome());
		System.out.println(p1.getSexo());
		System.out.println(p2.getSexo());
		
		

	}

}
