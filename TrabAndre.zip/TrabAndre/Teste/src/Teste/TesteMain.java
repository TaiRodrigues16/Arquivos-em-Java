package Teste;

import java.util.Date;

public class TesteMain {
		

		/**
		 * 
		 * @param args
		 * 
		 */
	
		public static void main(String[] args, Object String) {
			// TODO Auto-generated method stub
			
			TesteFunc p1;
			
			
			p1 = new TesteFunc(int i; String nome; String departamento; Date dataEntreBanco; String rg; double salario);
			
			
			
			
			


	}

}
