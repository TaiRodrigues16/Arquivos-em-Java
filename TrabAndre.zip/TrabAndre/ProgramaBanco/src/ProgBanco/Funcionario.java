package ProgBanco;

import java.sql.Date;

public class Funcionario {
	
	String nome;
	String departamento;
	Date dataEntreBanco;
	String rg;
	double salario;
	
	public Funcionario(){};
	
	/**
	 * Metodo construtor da Classe Funcionario.
	 * @param nome
	 * @param departamento
	 * @param dataEntreBanco
	 * @param rg
	 * @param salario
	 */
	
	public Funcionario(String nome, String departamento, Date dataEntreBanco, String rg, double salario){
		
		this.nome = nome;
		this.departamento = departamento;
		this.dataEntreBanco = dataEntreBanco;
		this.rg = rg;
		this.salario = salario;
		
}
	
	public static double Recebeaumento(double salario){
		double porcentagem;
		
		double result = 0;
		
		for(int i = 0; i <= 12; i++){
			porcentagem = 10;
			result = (salario * porcentagem)/100;
		}
		
		return result;
}
	
	public static double calculaGanhoAnual(double result){
		
		double resultPronto;
		
		result= Recebeaumento(result);
		
		resultPronto = result * 12;
		
		return resultPronto;
		
	}
}