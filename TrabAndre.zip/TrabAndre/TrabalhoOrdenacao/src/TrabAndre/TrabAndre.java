package TrabAndre;

import java.util.Random;

public class TrabAndre {
	
	public static boolean menor(int a, int b) {
		return a < b;
	}
	
	public static int[] selectionSort(int[] vetor, int l, int r){
		int i = 0, j = 0, aux = 0;
		for (i= l; i < r; i++) {
			int min = i;
			for(j = i+1; j <= r; j++){
				if(menor(vetor[j],vetor[min])){
					min = j;
				}				
			}
			aux = vetor[i];
			vetor[i]  = vetor[min];
			vetor[min] = aux;
		}
		return vetor;
	}
	
	public static int[] bolha(int[] vetor, int l, int r)
		{
		int i, j;
		for(i = l; i < r; i++){
			for(j = r; j > i; j--){
				if(menor(vetor[j], vetor[j-1])){
					int aux = vetor[j-1];
					vetor[j-1] = vetor[j];
					vetor[j] = aux;
				}
			}
		}
		
		//imprime na tela
		/*for (int k = 0; k < 10; k++) {
			System.out.print(vetor[k] + " ");
		}*/
		
		return vetor;
	}
	
	public static int[] quickSort(int[] vetor, int l, int r){
		int i = 0;
		if(r <= l)
			return null;
		//paticiona o vetor em 2 partes
		i = particiona(vetor,l,r);
		//chama o quicksort com  a metade a direita do vetor
        quickSort(vetor, l, i - 1);
        //chama o quicksort com a metade a esquerda do vetor;
        quickSort(vetor, i, r);	
		return vetor;
		
	}
	
	public static int particiona(int[] vetor, int l, int r){
		int i = l, j = r, pivo = 0, aux = 0;
		pivo = vetor[(l + r) / 2];
		while (i <= j) {
			//roda o while enquanto o valor da posi��o for
			//menor que o valor do pivo
            while (vetor[i] < pivo)
                  i++;
          //roda o while enquanto o valor da posi��o for 
          //maior que o valor do pivo
            while (vetor[j] > pivo)
                  j--;
            //quando os contadores se crus�o, encontro lugar do pivo
            if (i <= j) {
                  aux = vetor[i];
                  vetor[i] = vetor[j];
                  vetor[j] = aux;
                  i++;
                  j--;
            }
      }		
		return i;
	}
	
	public static int[] mergeSort(int[] vetor, int l, int r){
		//divide o vetor ao meio
		int m = (r+l)/2;
		//caso base
		if(r <= l)
			return null;
		//chama o mergeSort com a metada a esquerda do vetor
		mergeSort(vetor, l, m);
		//chama o mergeSort com a metade a direita do vetor
		mergeSort(vetor, m+1, r);
		//metodo que combina os 2 vetores
		vetor = merge(vetor,l,m,r);
		
		return vetor;
	}
	
	//intercala os elementos de forma de forma ordenada
	public static int[] merge(int[] vetor, int l, int m, int r){
		int i,j,k = 0;
		int tam = vetor.length;
		int[] aux = new int[tam];
		for (i = m+1;  i > l; i--) 
			aux[i-1] = vetor[i-1];
		for(j = m; j < r; j++)
			aux[r+m-j] = vetor[j+1];
		for(k = l; k <= r; k++)
			if(menor(aux[j], aux[i]))
				vetor[k] = aux[j--];
			else
				vetor[k] = aux[i++];
			
		return vetor;
	}
	
	public static void insercao(int[] vetor, int l, int r) {
		int i = 0;
		//coloca o menor elemento na primeira posi��o
		for (i = r; i > l; i--) {
			if (menor( vetor[i], vetor[i-1])) {
				int aux = vetor[i - 1];
				vetor[i - 1] = vetor[i];
				vetor[i] = aux;
			}
		}
		//ordena os elemento do vetor menos a primeira posi��o
		for (i = l + 2; i <= r; i++) {
			int j = i;
			int v = vetor[i];
			while (menor(v,vetor[j - 1])) {
				vetor[j] = vetor[j - 1];
				j--;
			}
			vetor[j] = v;

		}
		
		/*//imprime na tela
		for (int k = 0; k < 10; k++) {
			System.out.print(vetor[k] + " ");
		} */
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n = 100000;
		int[] vetor = new int[n];
		
		Random gerador = new Random(19700621);
		
		for (int i = 0; i < 100000; i++) 
		{ 
			vetor[i] = gerador.nextInt(25);
			//System.out.println(gerador.nextInt(25));
			
		}
		
		
		long tempoInicial = System.currentTimeMillis();
		
		quickSort(vetor,0, n-1 );
		
		long tempoFinal = System.currentTimeMillis();
		
		System.out.println("Quick Sort = " + (tempoFinal - tempoInicial) + " ms" );  
		
		 tempoInicial = System.currentTimeMillis();
		
		bolha(vetor,0, n-1);
		
        tempoFinal = System.currentTimeMillis();
		
		System.out.println("Bolha = " + (tempoFinal - tempoInicial) + " ms" );
		
		tempoInicial = System.currentTimeMillis();
		
		selectionSort(vetor,0, n-1);
		
		tempoFinal = System.currentTimeMillis();
		
		System.out.println("Selection Sort = " + (tempoFinal - tempoInicial) + " ms" );
		
		tempoInicial = System.currentTimeMillis();
		
		mergeSort(vetor,0, n-1);
		 
		tempoFinal = System.currentTimeMillis();
		
		System.out.println("Merge Sort = " + (tempoFinal - tempoInicial) + " ms" );
		
		tempoInicial = System.currentTimeMillis();
		
		insercao(vetor,0, n-1);
		
		tempoFinal = System.currentTimeMillis();
		
		System.out.println("Insercao = " + (tempoFinal - tempoInicial) + " ms" );

	}


}
