package Empregado;

public class Gerente {
	
	int senha;
	int numberFuncionarioGerente;
	
	

}
