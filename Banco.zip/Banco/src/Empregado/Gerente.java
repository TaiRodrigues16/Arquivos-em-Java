package Empregado;

public class Gerente extends Funcionario{
	
	int senha;
	int numeroFuncionarioGerenciados;
	

	public Gerente(){}
	
	public Gerente(int senha, int numeroFuncionarioGerenciados) {
		this.senha = senha;
		this.numeroFuncionarioGerenciados = numeroFuncionarioGerenciados;
	}	
	
	public boolean autentica(int senha){
		if(this.senha == senha){
			System.out.println("Acesso permitido");
			return true;
		}else{
			System.out.println("Acesso negativo");
			return false;
		}
	}
	
	public double getbonifica(){
		return this.salario*0.15;
	}

	/**
	 * @return the senha
	 */
	public int getSenha() {
		return senha;
	}

	/**
	 * @param senha the senha to set
	 */
	public void setSenha(int senha) {
		this.senha = senha;
	}

	/**
	 * @return the numeroFuncionarioGerenciados
	 */
	public int getNumeroFuncionarioGerenciados() {
		return numeroFuncionarioGerenciados;
	}

	/**
	 * @param numeroFuncionarioGerenciados the numeroFuncionarioGerenciados to set
	 */
	public void setNumeroFuncionarioGerenciados(int numeroFuncionarioGerenciados) {
		this.numeroFuncionarioGerenciados = numeroFuncionarioGerenciados;
	}
	
	

}
