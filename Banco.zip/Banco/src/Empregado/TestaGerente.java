package Empregado;



public class TestaGerente {

	public static void main(String[] args) {
	
		Gerente gerente = new Gerente();
		Funcionario f = new Funcionario();
		
		f.setSalario(1000);
		System.out.println(f.getbonifica());
		
		gerente.setNome("Jo�o da Silva");
		gerente.setSenha(123456);
		gerente.setSalario(2000);
		System.out.println(gerente.getbonifica());
		
		System.out.println(gerente.getNome());
		System.out.println(gerente.getSenha());
		
		
		gerente.autentica(123456);
				

	}

}
