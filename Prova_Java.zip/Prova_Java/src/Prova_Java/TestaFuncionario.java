package Prova_Java;

import java.util.Date;
import java.util.Scanner;

public class TestaFuncionario {

	public static void main(String[] args) {
		
		int opcao = 0;
		int numFun = 0;
		int cont = 0;
		Scanner teclado = new Scanner(System.in);
		Funcionario[] f = new Funcionario [100];
		
		while (opcao != 7){
			
			System.out.println("\tMenu");
			System.out.println("\t\t 1 - Cadastrar Numero de Funcionario ");
			System.out.println("\t\t 2 - Bonificar Funcionario ");
			System.out.println("\t\t 3 - Calcular Ganho Anual por Funcionario ");
			System.out.println("\t\t 4 - Calcula Ganho Anual Total ");
			System.out.println("\t\t 5 - Mostrar Funcionario ");
			System.out.println("\t\t 6 - Mostrar Todos os Funcionarios ");
			System.out.println("\t\t 7 - Sair");
			System.out.println("Digite uma opcao: ");
			opcao = teclado.nextInt();
			
			if (opcao == 1){
				if (cont < 100 && numFun <= 100){
					System.out.println("Quantos funcionarios deseja cadastrar? ");
					numFun = teclado.nextInt();
					for (int i = 0; i < numFun; i++){
						System.out.println("\nNome do Funcionario: ");
						String nome = teclado.next();
						teclado.nextLine();
						System.out.println("\nDepartamento: ");
						String departamento = teclado.next();
						teclado.nextLine();
						System.out.println("\nRG: ");
						String rg = teclado.next();
						System.out.println("\nSalario: ");
						double salario = teclado.nextFloat();
						Funcionario funcionario = new Funcionario(nome, departamento, salario, rg, new Date());
						f[cont] = funcionario;
						cont ++;
					}
				}
				else{
					System.out.println("Capacidade excedida!!!");
				}	
			}
			
			else if (opcao == 2){
				System.out.println("\nDigite a posicao do funcionario de 0 a " + (cont - 1) + ": ");
				int posicao = teclado.nextInt();
				System.out.println("\nDigite o valor da bonificacao: ");
				double aumento = teclado.nextDouble();
				f[posicao].bonifica(aumento);
			}
			
			else if (opcao == 3){
				System.out.println("\nDigite a posicao do funcionario de 0 a " + (cont - 1) + ": ");
				int posicao = teclado.nextInt();
				double ganhoAnual = f[posicao].calculaGanhoAnual();
				System.out.println(ganhoAnual);
			}
			
			else if (opcao == 4){
				double ganhoAnualTotal = 0;
				for (int i = 0; i < cont; i++){
					//ganhoAnualTotal = ganhoAnualTotal + f[i].calculaGanhoAnual();
					ganhoAnualTotal += f[i].calculaGanhoAnual();
				}
				System.out.println(ganhoAnualTotal);
			}
			
			else if (opcao == 5){
				System.out.println("\nDigite a posicao do funcionario de 0 a " + (cont - 1) + ": ");
				int posicao = teclado.nextInt();
				f[posicao].mostrar();
			}
			
			else if (opcao == 6){
				for (int i = 0; i < cont; i++) {
					f[i].mostrar();
				}
			}
			
		}
		
	}
	
}
