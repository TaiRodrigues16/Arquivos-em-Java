package Prova_Java;

import java.util.Date;

public class Funcionario {

	String nome;
	String departamento;
	double salario;
	String rg;
	Date dataEntrada;
	boolean estaNaEmpresa;
	
	public Funcionario(){}
	
	public Funcionario (String nome, String departamento, double salario, String rg, Date dataEntrada){
		this.nome = nome;
		this.departamento = departamento;
		this.rg = rg;
		this.dataEntrada = dataEntrada;
		this.salario = salario;
		this.estaNaEmpresa = true;
	}
	
	public void bonifica(double aumento){
		//this.salario = this.salario + aumento;
		this.salario += aumento;
	}
	
	public void demite(){
		this.estaNaEmpresa = false;
	}
	
	public double calculaGanhoAnual(){
		return this.salario*12;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public Date getDataEntrada() {
		return dataEntrada;
	}

	public void setDataEntrada(Date dataEntrada) {
		this.dataEntrada = dataEntrada;
	}

	public boolean isEstaNaEmpresa() {
		return estaNaEmpresa;
	}

	public void setEstaNaEmpresa(boolean estaNaEmpresa) {
		this.estaNaEmpresa = estaNaEmpresa;
	}
	
	public void mostrar(){
		System.out.println("Nome: " + this.nome);
		System.out.println("Departamento: " + this.departamento);
		System.out.println("Rg: " + this.rg);
		System.out.println("Salario: " + this.salario);
		System.out.println("Entrada na Empresa: " + this.dataEntrada);
		System.out.println("Esta na empresa: " + this.estaNaEmpresa);
	}
	
	
}
