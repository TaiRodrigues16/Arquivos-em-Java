package TrabalhodeProgramacao;

public class FuncinarioGraduado extends Funcionario{
	
	String Uni;
	
	public FuncinarioGraduado(){}
	
	public FuncinarioGraduado(String Uni){
		this.Uni = Uni;
	}
	
	public String getUni() {
		return Uni;
	}

	public void setUni(String Uni) {
		this.Uni = Uni;
	}
	
	public double CalcSalario (double salario){
		return this.salario = ((salario + (salario * 0.10)) +  (salario * 0.50)) + (salario * 1.0);
	}

	public void Mostrar(){
		System.out.println("Este funcionario concluiu o ensino basico!");
		System.out.println("Estudou: " + this.Uni);
		System.out.println("Seu salario eh: " + this.salario);
	}
}
