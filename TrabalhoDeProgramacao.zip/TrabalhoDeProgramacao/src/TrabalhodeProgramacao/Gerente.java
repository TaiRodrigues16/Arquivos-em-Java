package TrabalhodeProgramacao;

public class Gerente extends Funcionario {
	
	private double CalcSalario;

	public double CalcSalario(double salario){
		return this.CalcSalario(salario) + 1500;
	}
	
	
	public double getCalcSalario() {
		return CalcSalario;
	}



	public void setCalcSalario(double calcSalario) {
		CalcSalario = calcSalario;
	}


	public void Mostrar(){
		System.out.println("Este funcionario � Gerente!");
		System.out.println("Seu nome eh: " + this.nome);
		System.out.println("Seu salario eh: " + this.CalcSalario);
	}
	
}
