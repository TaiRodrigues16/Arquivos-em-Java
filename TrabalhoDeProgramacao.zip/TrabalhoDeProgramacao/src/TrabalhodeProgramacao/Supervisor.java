package TrabalhodeProgramacao;

public class Supervisor extends Funcionario{

	private double CalcSalario;

	public double CalcSalario(double salario){
		return this.CalcSalario(salario) + 600;
	}
	
	
	
	public double getCalcSalario() {
		return CalcSalario;
	}



	public void setCalcSalario(double calcSalario) {
		CalcSalario = calcSalario;
	}



	public void Mostrar(){
		System.out.println("Este funcionario � Supervisor!");
		System.out.println("Seu nome eh: " + this.nome);
		System.out.println("Seu salario eh: " + this.CalcSalario);
	}

}
