package TrabalhodeProgramacao;

public class Empresa {
	
	public static void main(String[] args){
		
		Funcionario[] f = new Funcionario[10];
		
		FuncinarioComBasico FuncinarioComBasico = null;
		FuncinarioComMedio FuncinarioComMedio = null;
		FuncinarioGraduado FuncinarioGraduado = null;
	
		int cont = 0;
		double gastoTotal = 0;
		double salario = 1000;
		
		for (int i = 0; i < f.length; i++) {
			if(cont < 4){
				FuncinarioComBasico fb = new FuncinarioComBasico();
				f[i] = fb;
				cont++;
				gastoTotal = fb.CalcSalario(salario) * 4;
			}else if(cont > 4 && cont < 8){
				FuncinarioComMedio fm = new FuncinarioComMedio();
				f[i] = fm;
				cont++;
				gastoTotal = fm.CalcSalario(salario) * 4;
			}else{
				FuncinarioGraduado fg = new FuncinarioGraduado();
				f[i] = fg;
				gastoTotal = fg.CalcSalario(salario) * 2;
			}
		}
		
		
	}

}
