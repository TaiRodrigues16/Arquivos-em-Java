package TrabalhodeProgramacao;

public class FuncinarioComBasico extends Funcionario{
	
	String escola;
	
	public FuncinarioComBasico(){}
	
	public FuncinarioComBasico(String escola){
		this.escola = escola;
	}
	
	public String getEscola() {
		return escola;
	}

	public void setEscola(String escola) {
		this.escola = escola;
	}
	
	public double CalcSalario (double salario){
		return this.salario = salario + (salario * 0.10);
	}

	public void Mostrar(){
		System.out.println("Este funcionario concluiu o ensino basico!");
		System.out.println("Estudou: " + this.escola);
		System.out.println("Seu salario eh: " + this.salario);
	}

}
