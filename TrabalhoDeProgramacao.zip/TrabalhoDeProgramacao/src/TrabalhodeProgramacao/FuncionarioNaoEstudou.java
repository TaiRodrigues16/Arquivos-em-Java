package TrabalhodeProgramacao;

public class FuncionarioNaoEstudou extends Funcionario{
	
	String codigoFunc;
	
	public FuncionarioNaoEstudou(){}
	
	public FuncionarioNaoEstudou(String codigoFunc){
		this.codigoFunc = codigoFunc;
	}
	
	public String getCodigoFunc() {
		return codigoFunc;
	}

	public void setCodigoFunc(String codigoFunc) {
		this.codigoFunc = codigoFunc;
	}
	
	public double CalcSalario (double salario){
		return this.salario = salario;
	}

	public void Mostrar(){
		System.out.println("Este funcionario n�o tem estudo!");
		System.out.println("Seu nome eh: " + this.nome);
		System.out.println("Seu codigo funcional: " + this.codigoFunc);
		System.out.println("Seu salario eh: " + this.salario);
	}

}
