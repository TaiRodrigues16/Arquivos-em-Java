package TrabalhodeProgramacao;

import java.util.Date;

public class Funcionario {
	
	String nome;
	String departamento;
	double salario;
	String rg;
	Date dataEntrada;
	
	public Funcionario(){}
	
	public Funcionario(String nome, String departamento, double salario, String rg, Date dataEntrada){
		
		this.nome = nome;
		this.departamento = departamento;
		this.salario = salario;
		this.rg = rg;
		this.dataEntrada = dataEntrada;
		
	}
	

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public Date getDataEntrada() {
		return dataEntrada;
	}

	public void setDataEntrada(Date dataEntrada) {
		this.dataEntrada = dataEntrada;
	}


}
