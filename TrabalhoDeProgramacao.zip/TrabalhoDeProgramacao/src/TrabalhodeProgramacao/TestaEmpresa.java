package TrabalhodeProgramacao;

public class TestaEmpresa {
	

	public static void main(String[] argrs){
		FuncinarioComBasico fB = new FuncinarioComBasico();
		FuncinarioComMedio fM = new FuncinarioComMedio (); 
		FuncinarioGraduado fG = new FuncinarioGraduado ();
		FuncionarioNaoEstudou fNe = new FuncionarioNaoEstudou();
		Vendedor Ven = new Vendedor();
		Supervisor Surp = new Supervisor();
		Gerente Ger = new Gerente(); 
		Funcionario Vendedor = Ven;
		Funcionario Supervisor = Surp;
		Funcionario Gerente = Ger;
		
		fB.CalcSalario(1000.00);
		fM.CalcSalario(1000.00);
		fG.CalcSalario(1000.00);
		fNe.CalcSalario(1000.00);
		fB.Mostrar();
		fM.Mostrar();
		fG.Mostrar();
		fNe.Mostrar();
		
		Ger.Mostrar();
		Surp.Mostrar();
		Ven.Mostrar();
	}

}
