package TrabalhodeProgramacao;

public class FuncinarioComMedio extends Funcionario {
	
	String escola;
	
	public FuncinarioComMedio(){}
	
	public FuncinarioComMedio(String escola){
		this.escola = escola;
	}
	
	public String getEscola() {
		return escola;
	}

	public void setEscola(String escola) {
		this.escola = escola;
	}
	
	public double CalcSalario (double salario){
		return this.salario = (salario + (salario * 0.10)) +  (salario * 0.50);
	}

	public void Mostrar(){
		System.out.println("Este funcionario concluiu o ensino medio!");
		System.out.println("Estudou: " + this.escola);
		System.out.println("Seu salario eh: " + this.salario);
	}

}
