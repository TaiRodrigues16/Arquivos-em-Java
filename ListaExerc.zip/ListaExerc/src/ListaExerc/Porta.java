package ListaExerc;

public class Porta {

	boolean aberta;
	String cor;
	double dimensaoX;
	double dimensaoY;
	double dimensaoZ;

	Porta() {
	}

	/**
	 * Metodo Construtor
	 * 
	 * @param aberta
	 * @param cor
	 * @param dimensaoX
	 * @param dimensaoY
	 * @param dimensaoZ
	 */

	public Porta(boolean aberta, String cor, double dimensaoX, double dimensaoY, double dimensaoZ) {

		this.aberta = aberta;
		this.cor = cor;
		this.dimensaoX = dimensaoX;
		this.dimensaoY = dimensaoY;
		this.dimensaoZ = dimensaoZ;

	}

	public boolean getAberta() {
		return aberta;
	}

	public void setAberta(boolean aberta) {
		this.aberta = aberta;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public double getDimensaoX() {
		return dimensaoX;
	}

	public void setDimensaoX(double d) {
		this.dimensaoX = d;
	}

	public double getDimensaoY() {
		return dimensaoY;
	}

	public void setDimensaoY(double d) {
		this.dimensaoY = d;
	}

	public double getDimensaoZ() {
		return dimensaoZ;
	}

	public void setDimensaoZ(double d) {
		this.dimensaoZ = d;
	}
	
	void pinta(String s){
		this.cor = s;  
        System.out.println(this.cor);  
	}

	public void fecha() {
		aberta = false;
		System.out.println("A porta est� fechada!");
	}

	public void abre() {
		aberta = true;
		System.out.println("A porta est� aberta");
	}

	public boolean estaAberta() {
		return aberta;
	}

	public String toString() {
		return estaAberta() ? "Aberta" : "Fechada";
	}

	public void MostraPortat() {

		System.out.println("Cor: " + this.cor);
		System.out.println("Dimensao x: " + this.dimensaoX + " m");
		System.out.println("Dimensao y: " + this.dimensaoY + " m");
		System.out.println("Dimensao z: " + this.dimensaoZ + " m");

	}

}
