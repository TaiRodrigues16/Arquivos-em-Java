package ListaExerc;

public class Casa {

	String cor;
	boolean porta1;
	boolean porta2;
	boolean porta3;
	boolean aberta;
	int porta01;
	int porta02;
	int porta03;
	int passaValor;

	Casa() {
	}

	/**
	 * Metodo Construtor
	 * 
	 * @param cor
	 * @param porta1
	 * @param porta2
	 * @param porta3
	 */

	public Casa(String cor, boolean porta1, boolean porta2, boolean porta3, int porta01, int porta02, int porta03,
			int passaValor, boolean aberta) {

		this.cor = cor;
		this.porta1 = porta1;
		this.porta2 = porta2;
		this.porta3 = porta3;
		this.porta01 = porta01;
		this.porta02 = porta02;
		this.porta03 = porta03;
		this.passaValor = passaValor;
		this.aberta = aberta;

	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public boolean isPorta1() {
		return porta1;
	}

	public void setPorta1(boolean porta1) {
		this.porta1 = porta1;
	}

	public boolean isPorta2() {
		return porta2;
	}

	public void setPorta2(boolean porta2) {
		this.porta2 = porta2;
	}

	public boolean isPorta3() {
		return porta3;
	}

	public void setPorta3(boolean porta3) {
		this.porta3 = porta3;
	}
	
	void pinta(String s){
		this.cor = s;  
        System.out.println(this.cor);  
	}

	public void setAberta(boolean aberta) {
		this.aberta = aberta;
	}

	public void fechar() {

		if (porta1 == false) {
			System.out.println("A porta est� fechada!");

		}

		if (porta2 == false) {
			System.out.println("A porta est� fechada!");

		}

		if (porta3 == false) {
			System.out.println("A porta est� fechada!");

		}

	}

	public void abrir() {

		if (porta1 == true || porta2 == true || porta3 == true) {
			System.out.println("A porta est� aberta!");
		}

	}

	public int abre(int passavalor) {
		return 1;
	}

	public int fecha(int passavalor) {
		return 0;
	}

	public void quantasPortasEstaoAbertas() {

		int soma = porta01 + porta02 + porta03;

		if (soma == 0) {
			System.out.println("Todas as portas est�o fechadas!");
		}

		if (soma == 3) {
			System.out.println("Todas as portas est�o abertas!");
		}

		else {
			System.out.println(soma + " -> Portas est�o abertas!");
		}
	}

	public void MostraCasa() {
		System.out.println("A casa eh: " + this.cor);
		System.out.println("Porta1: " + this.porta1);
		System.out.println("Porta2: " + this.porta2);
		System.out.println("Porta3: " + this.porta3);

	}

}
