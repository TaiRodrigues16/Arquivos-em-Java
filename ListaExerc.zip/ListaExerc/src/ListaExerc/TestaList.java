package ListaExerc;

public class TestaList {

	public static void main(String[] args) {

		System.out.println("Pessoa!");

		Pessoa pessoa = new Pessoa();

		pessoa.setNome("Josefina");
		pessoa.setIdade(16);
		pessoa.fazAniversario();
		pessoa.MostraList();

		System.out.println();

		System.out.println("Porta!");

		Porta porta = new Porta();

		porta.setCor("Vermelho");
		porta.setDimensaoX(22.0);
		porta.setDimensaoY(12.0);
		porta.setDimensaoZ(44.0);
		porta.setAberta(false);
		porta.MostraPortat();

		System.out.println("A porta est� " + porta);

		System.out.println();

		System.out.println("Casa!");

		Casa casa = new Casa();

		casa.setCor("Amarela");
		casa.MostraCasa();
		casa.porta01 = casa.fecha(casa.porta01);
		casa.porta02 = casa.fecha(casa.porta02);
		casa.porta03 = casa.fecha(casa.porta03);
		casa.quantasPortasEstaoAbertas();
		casa.setPorta1(false);
		casa.setPorta2(false);
		casa.setPorta3(false);

	}

}
