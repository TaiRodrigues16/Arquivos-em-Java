package ListaExerc;

public class Pessoa {

	String nome;
	int idade;
	int idadeAnoQueVem;

	Pessoa() {
	}

	/**
	 * Metodo Construtor da Classer Pessoa
	 * 
	 * @param nome
	 * @param idade
	 * @param idadeAnoQueVem
	 */

	public Pessoa(String nome, int idade, int idadeAnoQueVem) {

		this.nome = nome;
		this.idade = idade;
		this.idadeAnoQueVem = idadeAnoQueVem;

	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int string) {
		this.idade = string;
	}

	public int fazAniversario() {

		return idadeAnoQueVem = idade + 1;

	}

	public void MostraList() {
		System.out.println("Nome: " + this.nome);
		System.out.println("Idade: " + this.idade + " anos");
		System.out.println("Idade ano que vem: " + this.idadeAnoQueVem + " anos");
	}

}
