package FabricCar;

public class TestaCarro {
	
	public static void main(String[] args) {
		
		Carros c = new Carros("azul","palio",10.0, 200.0);
		Carros c2 = new Carros();
		c2.setCor("Preto fosco");
		c2.setModelo("Camaro");
		c2.setVelocidadeAtual(60.0);
		c2.setVelocidadeMax(250.0);
		
		Motor m2 = new Motor();
		m2.setPotencia(406.0);
		m2.setTipo("gasolina");
		c2.setMotor(m2);
		c2.mostraCarro();
		
		
		Motor m;
		m = new Motor();
		m.setTipo("flex");
		m.setPotencia(2.0);
		c.setMotor (m);
		c.mostraCarro();
		//c.getMotor().getPotencia();
		
		

	}

}
