package FabricCar;

public class Carros {
	
	private String cor;
	private String Modelo;
	private Double velocidadeMax;
	private Double velocidadeAtual;
	Motor Motor;
	
	public Carros(){};
	
	/**
	 * 
	 * @param cor
	 * @param Modelo
	 * @param velocidadeMax
	 * @param velocidadeAtual
	 * @param Motor
	 */
	
	public Carros(String cor, String Modelo, Double velocidadeMax, Double velocidadeAtual){
		
		this.cor = cor;
		this.Modelo = Modelo;
		this.velocidadeMax = (double) velocidadeMax;
		this.velocidadeAtual = (double) velocidadeAtual;
		
		
	}
	
	/**
	 * 
	 * @return
	 */

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public String getModelo() {
		return Modelo;
	}

	public void setModelo(String modelo) {
		Modelo = modelo;
	}

	public Double getVelocidadeMax() {
		return velocidadeMax;
	}

	public void setVelocidadeMax(Double velocidadeMax) {
		this.velocidadeMax = velocidadeMax;
	}

	public Double getVelocidadeAtual() {
		return velocidadeAtual;
	}

	public void setVelocidadeAtual(Double velocidadeAtual) {
		this.velocidadeAtual = velocidadeAtual;
	}

	public Motor getMotor() {
		return Motor;
	}

	public void setMotor(Motor motor) {
		Motor = motor;
	}
	
	public void mostraCarro(){
		System.out.println("Carro: ");
		System.out.println("Cor: " + this.cor);
		System.out.println("Modelo: " + this.Modelo);
		System.out.println("VelocidadeAtual: " + this.velocidadeAtual);
		System.out.println("VelocidadeMax: " + this.velocidadeMax);
		System.out.println("Motor: ");
		System.out.println("Potencia: " + this.Motor.getPotencia());
		System.out.println("Tipo: " + this.Motor.getTipo());

	}

	
	
	
	
		
	
	
}
