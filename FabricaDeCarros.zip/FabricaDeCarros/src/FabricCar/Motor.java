package FabricCar;

public class Motor {

	private Double potencia;
	private String tipo;
	
	public Motor(){}
	
	public Motor(Double potencia, String tipo){
		this.potencia = potencia;
		this.tipo = tipo;
	}

	public Double getPotencia() {
		return potencia;
	}

	public void setPotencia(Double potencia) {
		this.potencia = potencia;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}
