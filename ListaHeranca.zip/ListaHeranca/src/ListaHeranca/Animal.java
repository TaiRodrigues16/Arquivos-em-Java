package ListaHeranca;

import java.util.Scanner;

public class Animal {
	
	protected int idade;
	protected String nome;
	Cachorro Cachorro;
	Cavalo Cavalo;
	Preguica Preguica;
	
	public Animal() {}

	/**
	 * @param idade
	 * @param especie
	 * @param nome
	 */
	public Animal(int idade, String nome) {
		super();
		this.idade = idade;
		this.nome = nome;
	}
	
	public void som(){}
	
	public void DeveOque(){}

	/**
	 * @return the idade
	 */
	public int getIdade() {
		return idade;
	}

	/**
	 * @param idade the idade to set
	 */
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	/**
	 * 
	 * @return the nome
	 */

	public String getNome() {
		return nome;
	}
	
	/**
	 * 
	 * @param nome the nome to set
	 */

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void mostra(){
		
				System.out.println("Voce escolheu o animal cachorro! ");
				System.out.println("Seu som eh: ");
				Cachorro.som();
				System.out.println("Voce escolheu o animal cavalo! ");
				System.out.println("Seu som eh: ");
				Cavalo.som();
				System.out.println("Voce escolheu o animal preguica! ");
				System.out.println("Seu som eh: ");
				Preguica.som();
				
		
	}
	
}

	
