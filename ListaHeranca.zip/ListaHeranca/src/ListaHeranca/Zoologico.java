package ListaHeranca;

import java.util.Scanner;

public class Zoologico {

		public static void main(String[] args) {
			
			
			Cachorro cao = new Cachorro();
			Cavalo cavalo = new Cavalo();
			Preguica preguica = new Preguica();
			Veterinario veterinario = new Veterinario();
			
			// Animal cachorro = preguica;
			// cachorro.som();
			//cao.som();
			//cavalo.som();
			//preguica.som();
			
			Scanner teclado = new Scanner(System.in);
			int num = 0;
			
			Animal vetJaulas [] = new Animal[10];
			
			System.out.println("Vamos colocar cada animal em sua jaula!");
				
				for (int i = 0; i < vetJaulas.length; i++) {
					System.out.println();
					System.out.println("Coloque os animas em suas jaulas: ");
					System.out.println("[1] -> Cao");
					System.out.println("[2] -> Cavalo");
					System.out.println("[3] -> Preguica");
					System.out.println("Digite qual animal quer colocar: ");
					num = teclado.nextInt();
					
					if(num == 1){
						System.out.println("Jaula contem: ");
						cao.som();
						System.out.println("Ele vai: ");
						cao.DeveOque();
					}
					
					else if(num == 2){
						System.out.println("Jaula contem: ");
						cavalo.som();
						System.out.println("Ele vai: ");
						cavalo.DeveOque();
					}
					
					else if(num == 3){
						System.out.println("Jaula contem: ");
						preguica.som();
						System.out.println("Ele vai: ");
						preguica.DeveOque();
					}

				}
				
			System.out.println();
				
			System.out.println("Os animais est�o nas jaulas!!!");
			
			System.out.println();
			Animal animal = new Animal();
			veterinario.examinar(cao);
			
			

		}

	

}
