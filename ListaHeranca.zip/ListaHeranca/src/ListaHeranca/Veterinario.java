package ListaHeranca;

import java.util.Scanner;

public class Veterinario extends Animal{

	public void examinar(Animal animal){
		
		Scanner teclado = new Scanner (System.in);
		int opc = 0;
		
		System.out.println("Examinou o animal!");
		animal.som();
		
		
	}
		
	
}
