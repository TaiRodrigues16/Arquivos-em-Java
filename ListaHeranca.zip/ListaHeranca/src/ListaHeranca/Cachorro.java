package ListaHeranca;

public class Cachorro extends Animal {
	
	public Cachorro(){
		
	}
	
	public void som(){
		System.out.println("Au Au Au ..... AAuuuuuu");
		 
	}
	
	public String toString() {  
		   return "Cachorro";  
	}
	
	public void DeveOque(){
		System.out.println("Correr!");
	}
	
	
}
