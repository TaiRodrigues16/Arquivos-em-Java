package ListaHeranca;

public class Preguica extends Animal {
	
	public Preguica(){
		
	}
	
	public void som(){
		System.out.println("ZzZzZz ZzZzZz ..... ZzZzZzZzZzzzzzz");
	}
	
	public String toString() {  
		return "Preguica";  
	} 
	
	public void DeveOque(){
		System.out.println("Subir em arvores!");
	}
	
	
}
