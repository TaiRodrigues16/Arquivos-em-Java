package ListaHeranca;

public class Cavalo extends Animal {
	
	public Cavalo(){
		
	}
	
	public void som(){
		System.out.println("Lihh Lihh..... Lihhhhhhh");
	}
	
	public String toString() {  
		return "Cavalo";  
	} 
	
	public void DeveOque(){
		System.out.println("Correr!");
	}
	
	


}
