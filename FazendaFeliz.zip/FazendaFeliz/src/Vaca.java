
public class Vaca extends Animal{

	public Vaca() {
		
	}
	
	public void som(){
		System.out.println("Muuuuuuuuuuuuuuuu");
	}

}
