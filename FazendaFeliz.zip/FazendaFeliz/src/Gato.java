
public class Gato extends Animal{

	public Gato() {
		// TODO Auto-generated constructor stub
	}
	
	public void som(){
		System.out.println("Miiaauuuuu ..... Miiauuuu");
	}

}
