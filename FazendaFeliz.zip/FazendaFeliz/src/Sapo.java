
public class Sapo extends Animal {

	public Sapo() {
		// TODO Auto-generated constructor stub
	}
	
	public void som(){
		System.out.println("Webert .... Webert");
	}

}
