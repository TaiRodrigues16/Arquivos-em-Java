
public class Animal {

	protected int idade;
	protected String especie;
	protected float peso;
	
	public Animal() {}

	/**
	 * @param idade
	 * @param especie
	 * @param peso
	 */
	public Animal(int idade, String especie, float peso) {
		super();
		this.idade = idade;
		this.especie = especie;
		this.peso = peso;
	}
	
	public void som(){}

	/**
	 * @return the idade
	 */
	public int getIdade() {
		return idade;
	}

	/**
	 * @param idade the idade to set
	 */
	public void setIdade(int idade) {
		this.idade = idade;
	}

	/**
	 * @return the especie
	 */
	public String getEspecie() {
		return especie;
	}

	/**
	 * @param especie the especie to set
	 */
	public void setEspecie(String especie) {
		this.especie = especie;
	}

	/**
	 * @return the peso
	 */
	public float getPeso() {
		return peso;
	}

	/**
	 * @param peso the peso to set
	 */
	public void setPeso(float peso) {
		this.peso = peso;
	}
	
	

}
