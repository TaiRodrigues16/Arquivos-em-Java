
public class TestaAnimal {

	
	public static void main(String[] args) {
		
		Vaca vaca = new Vaca();
		Cachorro cao = new Cachorro();
		Gato xanim = new Gato();
		Sapo sapo = new Sapo();
		//Animal coelho = vaca;
		Animal coelho = xanim;
		coelho = cao;
		Animal boi = sapo;
		
		coelho.som();
		boi.som();
		
		

	}

}
