
public class Cachorro extends Animal {

	public Cachorro() {
		// TODO Auto-generated constructor stub
	}
	
	public void som(){
		System.out.println("Au Au Au ..... AAuuuuuu");
	}

}
